from sqlalchemy.ext.declarative import declarative_base
from psqlconfigutils import PsUtils
from models import User
user.address=relationship("Address",backref="user")





